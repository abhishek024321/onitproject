import { Gauge, Sparkles, Hash, Wallet } from "lucide-react";

export function mockDashboardData(filters) {
  return {
    company: "Abc Pvt Ltd",
    stats: [
      {
        key: "speed",
        icon: Gauge,
        label: "Speed",
        sub: "Avg resp time",
        value: "4.1h",
        change: 5,
      },
      {
        key: "quality",
        icon: Sparkles,
        label: "Quality",
        sub: "Happy Code",
        value: 45,
        change: 5,
      },
      {
        key: "quantity",
        icon: Hash,
        label: "Quantity",
        sub: "Closed calls (Day 0-2)",
        value: 250,
        change: null,
      },
      {
        key: "revenue",
        icon: Wallet,
        label: "Revenue",
        sub: null,
        value: "₹1,20,000",
        change: 8,
      },
    ],
    nps: { promotersPct: 25.5, detractorsPct: 3.5 },
    attention: { repeatBookings: 25, reVisit: 5, escalation: 10 },
    jobsOverview: {
      total: 120,
      new: 25,
      assigned: 45,
      completed: 30,
      cancelled: 15,
      partsPending: 5,
    },
    techniciansStatus: { active: 80, newAdded: 15, inactive: 65, blocked: 10 },
    speedTrend: [
      { label: "Today", hours: 3, pct: 20 },
      { label: "20th", hours: 5, pct: 30 },
      { label: "19th", hours: 8, pct: 55 },
      { label: "18th", hours: 6, pct: 35 },
      { label: "17th", hours: 5, pct: 25 },
    ],
    topLocations: [
      { name: "New Delhi", count: 11, lat: 28.6139, lng: 77.209 },
      { name: "Gurgaon", count: 5, lat: 28.4595, lng: 77.0266 },
      { name: "Pune", count: 12, lat: 18.5204, lng: 73.8567 },
      { name: "Kolkata", count: 10, lat: 22.5726, lng: 88.3639 },
      { name: "Bangalore", count: 8, lat: 12.9716, lng: 77.5946 },
    ],
    accountStatus: {
      availableBalance: "₹1,32,500",
      totalSpent: "₹1,32,500",
      jobsDone: 180,
      perUnitCost: "₹1,560",
    },
    callStatusDetails: [
      { day: "Mon", pending: 40, partPending: 30, closed: 55, cancelled: 15 },
      { day: "Tue", pending: 55, partPending: 25, closed: 60, cancelled: 20 },
      { day: "Wed", pending: 45, partPending: 35, closed: 100, cancelled: 25 },
      { day: "Thu", pending: 70, partPending: 40, closed: 85, cancelled: 30 },
      { day: "Fri", pending: 50, partPending: 20, closed: 65, cancelled: 15 },
      { day: "Sat", pending: 60, partPending: 30, closed: 50, cancelled: 20 },
      { day: "Sun", pending: 35, partPending: 15, closed: 40, cancelled: 10 },
    ],
    topTechnicians: [
      {
        id: "INA293",
        rating: 4,
        jobCount: 10,
        location: "Sector 58, Gurugram",
        phone: "+91 98765 43210",
        kyc: "verified",
      },
      {
        id: "INA294",
        rating: 4,
        jobCount: 10,
        location: "Sector 58, Gurugram",
        phone: "+91 98765 43211",
        kyc: "pending",
      },
      {
        id: "INA295",
        rating: 5,
        jobCount: 14,
        location: "Sector 21, Gurugram",
        phone: "+91 98765 43212",
        kyc: "verified",
      },
      {
        id: "INA296",
        rating: 3,
        jobCount: 7,
        location: "DLF Phase 3, Gurugram",
        phone: "+91 98765 43213",
        kyc: "pending",
      },
      {
        id: "INA297",
        rating: 4,
        jobCount: 9,
        location: "Sohna Road, Gurugram",
        phone: "+91 98765 43214",
        kyc: "verified",
      },
    ],
    activeStates: {
      activeCities: 24,
      activePincodes: 950,
      opportunityMissed: 20,
    },
    _filters: filters,
  };
}

export async function fetchDashboardData(filters) {
  await new Promise((r) => setTimeout(r, 300));
  return mockDashboardData(filters);
}